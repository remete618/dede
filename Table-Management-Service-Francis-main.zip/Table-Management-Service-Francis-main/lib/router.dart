import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:tmms/features/items/presentation/widgets/pages/checkout_page.dart';
import 'package:tmms/features/items/presentation/widgets/pages/login-callback_page.dart';
import 'package:tmms/features/items/presentation/widgets/pages/pay_page.dart';
import 'package:tmms/features/items/presentation/widgets/pages/tablemenu_page.dart';

import './features/items/presentation/widgets/pages/splash_page.dart';
import './features/items/presentation/widgets/pages/login_page.dart';
import './features/items/presentation/widgets/pages/account_page.dart';
import './features/items/presentation/widgets/pages/items_page.dart';
import './features/items/presentation/widgets/pages/settings_page.dart';
import 'features/items/presentation/widgets/pages/products_page.dart';
import 'app_shell.dart';

final _rootKey = GlobalKey<NavigatorState>();
final _tablesKey = GlobalKey<NavigatorState>();
final _drinksKey = GlobalKey<NavigatorState>();
final _settingsKey = GlobalKey<NavigatorState>();

final GoRouter router = GoRouter(
  navigatorKey: _rootKey,
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      pageBuilder: (context, state) =>
          const NoTransitionPage(child: SplashPage()),
    ),
    GoRoute(
      path: '/login',
      pageBuilder: (context, state) =>
          const NoTransitionPage(child: LoginPage()),
    ),
    GoRoute(
      path: '/account',
      pageBuilder: (context, state) =>
          const NoTransitionPage(child: AccountPage()),
    ),
    GoRoute(
      path: '/login-callback',
      builder: (context, state) => const LoginCallbackPage(),
    ),
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) {
        return AppShell(navigationShell: navigationShell);
      },
      branches: [
        StatefulShellBranch(
          navigatorKey: _tablesKey,
          routes: [
            GoRoute(
              path: '/tables',
              pageBuilder: (context, state) =>
                  const NoTransitionPage(child: ItemsPage()),
                  routes: [
                    GoRoute(
                      path: ':id/menu',
                      builder: (context, state) {
                        final tableId = int.parse(state.pathParameters['id']!);
                        return TableMenuPage(tableId: tableId);
                      },
                    ),
                    GoRoute(
                      path: ':id/menu/pay',
                      builder: (context, state) {
                        final tableId = int.parse(state.pathParameters['id']!);
                        return PayPage(tableId: tableId);
                      },
                    ),
                    GoRoute(
                      path: ':id/menu/pay/checkout',
                      builder: (context, state) {
                        final args = state.extra as Map<String, dynamic>;
                        final extra = state.extra as Map<String, dynamic>;
                        return CheckoutPage(
                          total: args['total'] as double,
                          tableId: args['tableId'] as int,
                          selectedQuantities: extra['selectedQuantities'] as Map<int, int>,
                          allLines: extra['allLines'] as List<Map<String, dynamic>>,
                        );
                      },
                    ),
                    
                  ],
            ),
          ],
        ),
        StatefulShellBranch(
          navigatorKey: _drinksKey,
          routes: [
            GoRoute(
              path: '/drinks',
              pageBuilder: (context, state) =>
                  const NoTransitionPage(child: ProductsPage()),
            ),
          ],
        ),
        StatefulShellBranch(
          navigatorKey: _settingsKey,
          routes: [
            GoRoute(
              path: '/settings',
              pageBuilder: (context, state) =>
                  const NoTransitionPage(child: SettingsPage()),
            ),
          ],
        ),
      ],
    ),
  ],
);
