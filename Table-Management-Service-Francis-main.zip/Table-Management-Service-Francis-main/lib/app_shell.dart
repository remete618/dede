import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:tmms/core/config.dart';

class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  @override
  Widget build(BuildContext context) {
    final index = navigationShell.currentIndex;

    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: NavigationBar(
      backgroundColor: bgClr,
        selectedIndex: index,
        onDestinationSelected: (newIndex) {
            final currentIndex = navigationShell.currentIndex;

          navigationShell.goBranch(
            newIndex,
            initialLocation: newIndex == currentIndex,
          );
        },
        destinations: const [
          NavigationDestination(
            selectedIcon: Icon(Icons.table_bar),
            icon: Icon(Icons.table_bar_outlined),
            label: 'Tische',
          ),
          NavigationDestination(
            selectedIcon: Icon(Icons.local_drink_sharp),
            icon: Icon(Icons.local_drink_outlined),
            label: 'Produkte',
          ),
          NavigationDestination(
            selectedIcon: Icon(Icons.settings),
            icon: Icon(Icons.settings_outlined),
            label: 'Einstellungen',
          ),
          
        ],
      ),
    );
  }
}
