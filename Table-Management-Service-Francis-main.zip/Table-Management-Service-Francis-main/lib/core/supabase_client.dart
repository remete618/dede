import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';

class Supa {
  static Future<void> init() async {
    await Supabase.initialize(
      url: supabaseUrl, 
      anonKey: supabaseAnonKey,
       authOptions: FlutterAuthClientOptions(authFlowType: AuthFlowType.pkce), 
       );
  }

  static SupabaseClient get client => Supabase.instance.client;
}
