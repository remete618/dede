//SUPABASE RELATED
import 'package:flutter/material.dart';

const supabaseUrl = 'https://owdjzoztfqdhcktygyxi.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im93ZGp6b3p0ZnFkaGNrdHlneXhpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMzE3MzEsImV4cCI6MjA3NTYwNzczMX0.4tAeQop2HbsdgbtJPQgYorrvjzMFiEZn4QNn_a_mINQ';
final root = Uri.base.origin;
const itemsTable = 'table';


//FONTS AND UI
const double fabTextSize = 18;
const double abTextSize = 30;
Color? bgClr = Colors.grey[100];