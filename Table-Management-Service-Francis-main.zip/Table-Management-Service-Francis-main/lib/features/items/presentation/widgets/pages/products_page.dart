import 'package:flutter/material.dart';
import 'package:tmms/core/config.dart';
import 'package:tmms/features/items/data/category.dart';
import 'package:tmms/features/items/data/product.dart';
import 'package:tmms/features/items/data/repos/products_repository.dart';
import 'package:tmms/features/items/presentation/widgets/add_product_dialog.dart';
import 'package:tmms/features/items/presentation/widgets/edit_product_dialog.dart';
import '../product_card.dart';

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key});

  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  late final ProductRepository repo;
  late final Stream<List<Product>> _productsStream;
  late final Future<List<Category>> _categoriesFuture;

  @override
  void initState() {
    super.initState();
    repo = ProductRepository();
    _productsStream = repo.streamAll();
    _categoriesFuture = repo.fetchCategories();
  }



  Future<void> _confirmDeleteProduct(BuildContext context, Product product) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Produkt löschen'),
        content: Text('Möchtest du wirklich "${product.name ?? '(no name)'}" löschen?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Abbrechen'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Löschen'),
          ),
        ],
      ),
    );

  if (confirmed != true) return;

  try {
    await repo.delete(product.id);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Produkt gelöscht')),
      );
    }
  } catch (e) {
    
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Fehler beim Löschen: $e')),
      );
    }
  }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Category>>(
      future: _categoriesFuture,
      builder: (context, catSnap) {
        if (catSnap.hasError) {
          return Scaffold(
            backgroundColor: bgClr,
            appBar: AppBar(backgroundColor: bgClr, title: const Text('Produkte', style: TextStyle(
              fontVariations: [
                FontVariation('wght', 700),
                FontVariation.opticalSize(abTextSize),              
              ]
            ),), ),
            
            body: Center(child: Text('Kategorien konnten nicht geladen werden:\n${catSnap.error}')),
          );
        }
        if (!catSnap.hasData) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final categories = catSnap.data!;
        if (categories.isEmpty) {
          return Scaffold(
            backgroundColor: bgClr,
            appBar: AppBar(title: const Text('Produkte', style: TextStyle(
              fontVariations: [
                FontVariation('wght', 700),
                FontVariation.opticalSize(abTextSize),
              
              ]
            ),), ),
            floatingActionButton: FloatingActionButton(
              child: const Icon(Icons.add),
              onPressed: () async {
                await showDialog<bool>(
                  context: context,
                  builder: (_) => AddProductDialog(repo: repo),
                );
              },
            ),
            body: const Center(child: Text('Keine Kategorien gefunden, fügen sie zuerst welche hinzu.')),
          );
        }

        return DefaultTabController(
          length: categories.length,
          child: Scaffold(
            backgroundColor: bgClr,
            appBar: AppBar(backgroundColor: bgClr, centerTitle: true,title: const Text('Produkte', style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
              fontStyle: FontStyle.normal,
              fontSize: abTextSize,
              
            ),), 
              bottom: TabBar(
                isScrollable: true,
                tabs: [for (final c in categories) Tab(
                  text: c.name,
                  icon: Icon(_getIconForCategory(c.name)),
                  )],
              ),
            ),

            floatingActionButton: SizedBox(
              width: MediaQuery.of(context).size.width * 0.9, 
              child: FloatingActionButton.extended(
                onPressed: () async {
                  await showDialog<bool>(
                  context: context,
                  builder: (_) => AddProductDialog(repo: repo),
                ); },
      label: const Text(
        'Produkt hinzufügen',
        style: TextStyle(fontSize: fabTextSize),
      ),
      icon: const Icon(Icons.local_drink),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),
  ),

            body: StreamBuilder<List<Product>>(
              stream: _productsStream,
              builder: (context, prodSnap) {
                if (prodSnap.hasError) {
                  return Center(
                    child: Text(
                      'Failed to load products:\n${prodSnap.error}',
                      style: const TextStyle(color: Colors.red),
                    ),
                  );
                }
                if (!prodSnap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final products = prodSnap.data!;

                return TabBarView(
                  children: [

                    for (final cat in categories)
                      _ProductsCategoryTab(
                        category: cat,
                        products: products.where((p) => p.categoryId == cat.id).toList(),
                        onEdit: (product) async {
                          final result = await EditProductDialog.prompt(
                            context: context,
                            categories: categories,
                            initialName: product.name ?? '',
                            initialPrice: product.price ?? 0.0,
                            initialCategoryId: product.categoryId,
                          );

                          if (result == null) return;

                          await repo.update(
                            id: product.id,
                            name: result.name,
                            price: result.price,
                            categoryId: result.categoryId,
                          );
                        },
                        onDelete: (product) => _confirmDeleteProduct(context, product),
                      ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }
}

class _ProductsCategoryTab extends StatelessWidget {
  const _ProductsCategoryTab({
    required this.category,
    required this.products,
    required this.onEdit,
    required this.onDelete,
  });

  final Category category;
  final List<Product> products;
  final Future<void> Function(Product product) onEdit;
  final Future<void> Function(Product product) onDelete;

  @override
  Widget build(BuildContext context) {
    if (products.isEmpty) {
      return Center(child: Text('No products in "${category.name}"'));
    }

    final categoryIcon = _getIconForCategory(category.name);

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: products.length,
      separatorBuilder: (_, __) => const SizedBox(height: 16),
      itemBuilder: (context, index) {
        final p = products[index];

        return ProductCard(
          name: p.name ?? '(no name)',
          price: p.price ?? 0.0,
          onEdit: () => onEdit(p),
          onDelete: () => onDelete(p),
          icon: categoryIcon,
        );
      },
    );
  }
}

IconData _getIconForCategory(String categoryName) {
  final name = categoryName.toLowerCase();
  if (name.contains('snack') ) return Icons.fastfood;
  if (name.contains('shot') ) return Icons.local_drink_sharp;
  if (name.contains('gericht') || name.contains('Gericht')) return Icons.restaurant;
  
  return Icons.sports_bar;
 
}