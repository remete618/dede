import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:tmms/core/config.dart';
import 'package:tmms/core/supabase_client.dart';
import 'package:tmms/features/items/data/category.dart';
import 'package:tmms/features/items/data/tablefr.dart';
import 'package:tmms/features/items/data/product.dart';
import 'package:tmms/features/items/data/repos/order_repository.dart';
import 'package:tmms/features/items/data/repos/products_repository.dart';
import 'package:tmms/features/items/data/repos/tables_repository.dart';

class TableMenuPage extends StatefulWidget {
  const TableMenuPage({super.key, required this.tableId});
  final int tableId;
  

  @override
  State<TableMenuPage> createState() => _TableMenuPageState();
}

class _TableMenuPageState extends State<TableMenuPage> {
  final _productRepo = ProductRepository();
  final _orderRepo = OrderRepository();
  final _tablesRepo = TablesRepository();
  TableFr? _table;

  

  DateTime? _orderTimestamp;

  // cart: productId -> qty
  final Map<int, int> _cart = {};

  bool _creatingOrder = true;
  bool _checkoutBusy = false;

  Future<void> _loadTable() async {
  final t = await _tablesRepo.findTableById(widget.tableId);
  if (!mounted) return;
  setState(() {
    _table = t;
  });
}

  @override
  void initState() {
    super.initState();

    final supabase = Supa.client;

    if (supabase.auth.currentSession != null) {
      _initOrder();
    } else {
      supabase.auth.onAuthStateChange
          .firstWhere((e) => e.session != null)
          .then((_) {
        if (mounted) _initOrder();
      });
    }
    _loadTable();
  }

  Future<void> _initOrder() async {
    try {
      final ts = await _orderRepo.getOrCreateOrder(widget.tableId);
      if (!mounted) return;
      setState(() {
        _orderTimestamp = ts;
        _creatingOrder = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _creatingOrder = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Konnte keine Bestellung erstellen: $e')),
      );
    }
  }

  void _add(Product p) {
    setState(() {
      _cart[p.id] = (_cart[p.id] ?? 0) + 1;
    });
  }

  void _remove(Product p) {
    final current = _cart[p.id] ?? 0;
    if (current <= 1) {
      setState(() => _cart.remove(p.id));
    } else {
      setState(() => _cart[p.id] = current - 1);
    }
  }

  int get _totalItems => _cart.values.fold(0, (a, b) => a + b);

  Future<void> _checkout() async {
    final ts = _orderTimestamp;
    if (ts == null) return;
    if (_cart.isEmpty) return;

    setState(() => _checkoutBusy = true);

    try {
      for (final entry in _cart.entries) {
        await _orderRepo.addProduct(
          tableId: widget.tableId,
          orderTimestamp: ts,
          productId: entry.key,
          quantity: entry.value,
        );
      }

      if (!mounted) return;
      setState(() {
        _cart.clear();
        _checkoutBusy = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erfolgreich zum Tisch hinzugefuegt')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _checkoutBusy = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Checkout failed: $e')),
      );
    }
  }

  Future<void> _deleteCurrentTable() async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Tisch löschen'),
      content: Text('Möchten Sie ${_table?.name ?? 'Loading...'} wirklich löschen?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: Colors.red),
          onPressed: () => Navigator.pop(ctx, true), 
          child: const Text('Löschen')
        ),
      ],
    ),
  );
  if (confirmed != true) return;

  try {
    await _tablesRepo.delete(widget.tableId);

    if (!mounted) return;
    
    context.go('/tables');
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tisch erfolgreich gelöscht')),
      );
  } catch (e) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Fehler beim Löschen: $e')),
    );
  }
}


  @override
  Widget build(BuildContext context) {
    final ts = _orderTimestamp;

    return FutureBuilder<List<Category>>(
      future: _productRepo.fetchCategories(),
      builder: (context, catSnap) {
        if (catSnap.hasError) {
          return Scaffold(
            appBar: AppBar(title: Text('Menu – ${_table?.name ?? 'Loading...'}')),
            body: Center(
              child: Text('Konnte keine Kategorien laden:\n${catSnap.error}'),
            ),
          );
        }
        if (!catSnap.hasData) {
          return Scaffold(
            appBar: AppBar(title: Text('Menu – ${_table?.name ?? 'Loading...'}')),
            body: const Center(child: CircularProgressIndicator()),
          );
        }

        final categories = catSnap.data!;
        if (categories.isEmpty) {
          return Scaffold(
            appBar: AppBar(title: Text('Menu – ${_table?.name ?? 'Loading...'}')),
            body: const Center(child: Text('No categories found.')),
          );
        }

        return DefaultTabController(
          length: categories.length,
          child: Scaffold(
            backgroundColor: bgClr,
            appBar: AppBar(
              backgroundColor: bgClr,
              title: Text('Menu – ${_table?.name ?? 'Loading...'}'),
              actions: [
                IconButton(
                  icon: const Icon(Icons.payments_outlined),
                  tooltip: 'Pay',
                  onPressed: () {
                    context.go('/tables/${widget.tableId}/menu/pay');
                  },
                ),
                if (ts != null)
                  Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Center(
                      child: Text(
                        'Order: ${ts.toLocal().toString().substring(11, 19)}',
                        style: Theme.of(context).textTheme.labelMedium,
                      ),
                    ),
                  ),
              ],
              bottom: TabBar(
                isScrollable: true,
                tabs: [for (final c in categories) Tab(text: c.name)],
              ),
            ),

            body: _creatingOrder
                ? const Center(child: CircularProgressIndicator())
                : StreamBuilder<List<Product>>(
                    stream: _productRepo.streamAll(),
                    builder: (context, prodSnap) {
                      if (prodSnap.hasError) {
                        return Center(
                          child: Text('Konnte Produkte nicht laden:\n${prodSnap.error}'),
                        );
                      }
                      if (!prodSnap.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      final products = prodSnap.data!;

                      return TabBarView(
                        children: [
                          for (final cat in categories)
                            _CategoryProductsView(
                              category: cat,
                              products: products
                                  .where((p) => p.categoryId == cat.id)
                                  .toList(),
                              cart: _cart,
                              onAdd: _add,
                              onRemove: _remove,
                            ),
                        ],
                      );
                    },
                  ),
                      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
          floatingActionButton: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.bottomLeft,
                  child: FloatingActionButton.extended(
                    heroTag: 'delete_btn', 
                    onPressed: () => _deleteCurrentTable(),
                    backgroundColor: Colors.red,
                    icon: const Icon(Icons.delete, color: Colors.white),
                    label: const Text('Löschen', style: TextStyle(color: Colors.white)),
                  ),
                ),

                Align(
                  alignment: Alignment.bottomRight,
                  child: FloatingActionButton.extended(
                    heroTag: 'cart_btn', 
                    onPressed: (_totalItems == 0 || _checkoutBusy || _orderTimestamp == null)
                        ? null
                        : _checkout,
                    icon: _checkoutBusy
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.shopping_cart),
                    label: Text(_checkoutBusy ? 'Lädt...' : 'Hinzufügen ($_totalItems)'),
                  ),
                ),
              ],
            ),
          ),),
        );
      },
    );
  }
}

class _CategoryProductsView extends StatelessWidget {
  const _CategoryProductsView({
    required this.category,
    required this.products,
    required this.cart,
    required this.onAdd,
    required this.onRemove,
  });

  final Category category;
  final List<Product> products;
  final Map<int, int> cart;
  final void Function(Product) onAdd;
  final void Function(Product) onRemove;

  @override
  Widget build(BuildContext context) {
    if (products.isEmpty) {
      return Center(child: Text('No products in "${category.name}"'));
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: products.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final p = products[i];
        final qty = cart[p.id] ?? 0;

        return ListTile(
          title: Text(p.name ?? '(no name)'),
          subtitle: Text(p.price == null ? '' : '€${p.price!.toStringAsFixed(2)}'),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                onPressed: qty == 0 ? null : () => onRemove(p),
                icon: const Icon(Icons.remove_circle_outline),
              ),
              SizedBox(
                width: 24,
                child: Text('$qty', textAlign: TextAlign.center),
              ),
              IconButton(
                onPressed: () => onAdd(p),
                icon: const Icon(Icons.add_circle_outline),
              ),
            ],
          ),
        );
      },
    );
  }
}
