import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../../core/supabase_client.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  bool _didRun = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _decide());
  }

  Future<void> _decide() async {
    if (_didRun) return;
    _didRun = true;

    final supabase = Supa.client;
    final initial = await supabase.auth.onAuthStateChange.first;
    final session = initial.session;

    debugPrint('session null? ${session == null}');
    debugPrint('user: ${supabase.auth.currentUser?.email}');

    if (!mounted) return;
    context.go(session == null ? '/login' : '/tables');
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
