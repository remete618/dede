import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:tmms/core/config.dart';
import 'package:tmms/core/supabase_client.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  late final StreamSubscription<AuthState> _authSubscription;

  String get _emailRedirectTo {
    if (kIsWeb) {
      return '${Uri.base.origin}/login-callback';
    }
    return 'io.supabase.flutterquickstart://login-callback/';
  }

  @override
  void initState() {
    super.initState();
    final supabase = Supa.client;
    _authSubscription = supabase.auth.onAuthStateChange.listen((event) {
      final session = event.session;
      if (!mounted) return;
      if (session != null) {
        context.go('/account');
      }
    });
  }

  @override
  void dispose() {
    _emailController.dispose();
    _authSubscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(30),
        children: [
          TextFormField(
            controller: _emailController,
            decoration: const InputDecoration(
              label: Text('Email'),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () async {
              final email = _emailController.text.trim();
              print('redirectTo: $_emailRedirectTo');

              try {
                final supabase = Supa.client;
                await supabase.auth.signInWithOtp(
                  email: email,
                  emailRedirectTo: _emailRedirectTo,
                );

                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Email wurde versendet!')),
                );
              } on AuthException catch (error) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(error.message),
                    backgroundColor: Theme.of(context).colorScheme.error,
                  ),
                );
              } catch (_) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('Fehler beim Versenden, bitte erneut versuchen!'),
                    backgroundColor: Theme.of(context).colorScheme.error,
                  ),
                );
              }
            },
            child: const Text('login'),
          ),
        ],
      ),
    );
  }
}
