import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:tmms/core/config.dart';
import 'package:tmms/features/items/presentation/widgets/edit_table_dialog.dart';
import '../../../data/repos/tables_repository.dart';
import '../../../data/tablefr.dart';
import '/../../features/items/data/user.dart';
import '../add_item_dialog.dart';
import 'package:reorderables/reorderables.dart';


class ItemsPage extends StatefulWidget {
  const ItemsPage({super.key});

  @override
  State<ItemsPage> createState() => _ItemsPageState();
}

class _ItemsPageState extends State<ItemsPage> {
  int currentPageIndex = 0;
  final _repo = TablesRepository();
  bool _busy = false;
  int? _selectedWaiterId;
  List<TableFr> _localItems = []; //maybe replaced with persistent SB collumn



//hardcoded values just for presentation, 100% change later to stream
  final List<UserModel> _waiters =  [
    UserModel(id: 1, name: 'Timon'),
    UserModel(id: 2, name: 'Benni'),
    UserModel(id: 3, name: 'Michael'),
  ];

  final List<Color> _waiterColors =  [
    Colors.amberAccent,
    Colors.lightGreenAccent,
    Colors.tealAccent,
  ];


 //bool _loadingUsers = true;

  @override
  void initState() {
    super.initState();
    //_loadUsers();
  }


  Color _colorForWaiter(int? waiterId) {
  if (waiterId == null) {
    return Colors.grey.shade200; 
  }

  final index = _waiters.indexWhere((w) => w.id == waiterId);

  if (index == -1) {
    return Colors.grey.shade200;
  }

  return _waiterColors[index % _waiterColors.length];
}



/*
  Future<void> _loadUsers() async {
    try {
      final users = await _repo.fetchUsers();
      if (!mounted) return;
      setState(() {
        _users = users;
        _loadingUsers = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loadingUsers = false);
    }
  }

  String _waiterNameFor(TableFr item) {
    if (item.waiterId == null) return 'Offen';
    final found = _users.firstWhere(
      (u) => u.id == item.waiterId,
      orElse: () => UserModel(id: -1, name: 'Offen'),
    );
    return found.id == -1 ? 'Unknown' : found.name;
  }
*/
  
  String _waiterNameFor(TableFr item) {
  if (item.waiterId == null) return 'Offen';

  final found = _waiters.firstWhere(
    (w) => w.id == item.waiterId,
    orElse: () => UserModel(id: -1, name: 'Offen'),
  );

  return found.name;
}



  Future<void> _add() async {
   final result = await AddItemDialog.prompt(context, _waiters);

    if (result == null) return;

    setState(() => _busy = true);
    try {
      await _repo.add(
        name: result.tableName,
        waiterId: result.waiterId,
        peopleCount: result.peopleCount,
      );
    } on PostgrestException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Hinzufuegen gescheitert: ${e.message}')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

   Future<void> _edit(TableFr item) async {
    final result = await EditTableDialog.prompt(
      context: context,
      users: _waiters,
      initialTableName: item.name,
      initialPeopleCount: item.peopleCount ?? 0,
      initialWaiterId: item.waiterId,
    );

    if (result == null) return;
  
    setState(() => _busy = true);
    try {
      await _repo.update(
        id: item.id,
        name: result.tableName,
        waiterId: result.waiterId, 
        peopleCount: result.peopleCount == 0 ? null : result.peopleCount,
      );
    } on PostgrestException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Bearbeiten gescheitert: ${e.message}')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }


 Future<void> _confirmDelete(BuildContext context, TableFr item) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Tisch Loeschen'),
      content: Text('Tisch Loeschen? "${item.name}"?'),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(false),
          child: const Text('Abbrechen'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(dialogContext).pop(true),
          child: const Text('Loeschen'),
        ),
      ],
    ),
  );
  if (confirmed != true) return;

  setState(() => _busy = true);
  try {
    await _repo.delete(item.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Tisch "${item.name}" gelöscht')),
    );
  } on PostgrestException catch (e) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Löschen gescheitert: ${e.message}')),
    );
  } finally {
    if (mounted) setState(() => _busy = false);
  }
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgClr,
  appBar: AppBar(
    centerTitle: true,
    title: const Text('Deine Tische',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        letterSpacing: -1,
                      ),
                    ),
                    /*
    title: const Text('Deine Tische', style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
              fontStyle: FontStyle.normal,
              fontSize: abTextSize,
              
            ),),*/
    backgroundColor: bgClr,
    elevation: 0,
      actions: [
      IconButton(icon: Icon(Icons.search), onPressed: () {}),
      IconButton(icon: Icon(Icons.filter_2), onPressed: () {}),
    ],
  ),
    body: StreamBuilder<List<TableFr>>(
        stream: _repo.streamAll(),
        builder: (context, snap) {
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          if (_localItems.isEmpty ||
              _localItems.length != snap.data!.length) {
            _localItems = List.from(snap.data!);
          }

          final items = _localItems;
          if (items.isEmpty) {
            return const Center(child: Text('Noch keine Tische, druecke + um einen hinzuzufuegen'));
          }

          return LayoutBuilder(
            builder: (context, constraints) {
              final width = constraints.maxWidth;
              final crossAxisCount = width > 900
                  ? 4
                  : width > 600
                      ? 3
                      : 2;


    final tileWidth =
      (constraints.maxWidth - (16 * (crossAxisCount + 1))) /
        crossAxisCount;
          return ReorderableWrap(
            needsLongPressDraggable: false,
            spacing: 16,
            runSpacing: 16,
            padding: const EdgeInsets.all(16),
            onReorder: (oldIndex, newIndex) {
            setState(() {
              final item = _localItems.removeAt(oldIndex);
              _localItems.insert(newIndex, item);
            });
          },

            children: List.generate(items.length, (index) {
              final item = items[index];
              final waiterName = _waiterNameFor(item);
              final peopleLabel = item.peopleCount == null
                  ? ''
                  : 'Anzahl an Personen: ${item.peopleCount}';
              final tileColor = _colorForWaiter(item.waiterId);

              return SizedBox(
                key: ValueKey(item.id), 
                width: tileWidth,
                height: tileWidth,
                child: GestureDetector(
                  onTap: () => context.go('/tables/${item.id}/menu'),
                  child: Card(
                    color: tileColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(
                        width: 2,
                        color: Colors.black.withOpacity(0.15),
                      ),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          top: 6,
                          left: 6,
                          child: IconButton(
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: _busy ? null : () => _edit(item),
                          ),
                        ),
                        Positioned(
                          top: 6,
                          right: 6,
                          child: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: _busy
                                ? null
                                : () => _confirmDelete(context, item),
                            color: Colors.red,
                          ),
                        ),
                        Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                item.name,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                waiterName,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                              if (peopleLabel.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(
                                  peopleLabel,
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          );

            },
          );
        },
      ),
      floatingActionButton: SizedBox(
    width: MediaQuery.of(context).size.width * 0.9,
    child: FloatingActionButton.extended(
      onPressed: _busy ? null: _add,
      label: const Text(
        'Tisch hinzufügen',
        style: TextStyle(fontSize: fabTextSize),
      ),
      icon: const Icon(Icons.table_bar),
      //lets decide later: backgroundColor: Color.fromARGB(255, 155, 239, 255),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),
  ),

    );
  }
}
