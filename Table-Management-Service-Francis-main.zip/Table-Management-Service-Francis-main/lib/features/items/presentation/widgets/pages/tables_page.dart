import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:tmms/features/items/presentation/widgets/edit_table_dialog.dart';
import '../../../data/repos/tables_repository.dart';
import '../../../data/tablefr.dart';
import '/../../features/items/data/user.dart';
import '../add_item_dialog.dart';

class ItemsPage extends StatefulWidget {
  const ItemsPage({super.key});

  @override
  State<ItemsPage> createState() => _ItemsPageState();
}

class _ItemsPageState extends State<ItemsPage> {
  int currentPageIndex = 0;
  final _repo = TablesRepository();
  bool _busy = false;

  List<UserModel> _users = [];
  bool _loadingUsers = true;

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    try {
      final users = await _repo.fetchUsers();
      if (!mounted) return;
      setState(() {
        _users = users;
        _loadingUsers = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loadingUsers = false);
    }
  }

  String _waiterNameFor(TableFr item) {
    if (item.waiterId == null) return 'Offen';
    final found = _users.firstWhere(
      (u) => u.id == item.waiterId,
      orElse: () => UserModel(id: -1, name: 'Offen'),
    );
    return found.id == -1 ? 'Unknown' : found.name;
  }

  Future<void> _add() async {
    if (_loadingUsers) {
      await _loadUsers();
    }

    final result = await AddItemDialog.prompt(context, _users);
    if (result == null) return;

    setState(() => _busy = true);
    try {
      await _repo.add(
        name: result.tableName,
        waiterId: result.waiterId,
        peopleCount: result.peopleCount,
      );
    } on PostgrestException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Hinzufuegen gescheitert: ${e.message}')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

   Future<void> _edit(TableFr item) async {
    if (_loadingUsers) {
      await _loadUsers();
    }
  
    final result = await EditTableDialog.prompt(
      context: context,
      users: _users,
      initialTableName: item.name,
      initialPeopleCount: item.peopleCount ?? 0,
      initialWaiterId: item.waiterId,
    );
    if (result == null) return;
  
    setState(() => _busy = true);
    try {
      await _repo.update(
        id: item.id, 
        name: result.tableName,
        peopleCount: result.peopleCount == 0 ? null : result.peopleCount,
      );
    } on PostgrestException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Bearbeiten gescheitert: ${e.message}')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }


 Future<void> _confirmDelete(BuildContext context, TableFr item) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Tisch Loeschen'),
      content: Text('Tisch Loeschen? "${item.name}"?'),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(false),
          child: const Text('Abbrechen'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(dialogContext).pop(true),
          child: const Text('Loeschen'),
        ),
      ],
    ),
  );
  if (confirmed != true) return;

  setState(() => _busy = true);
  try {
    await _repo.delete(item.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Tisch "${item.name}" gelöscht')),
    );
  } on PostgrestException catch (e) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Löschen gescheitert: ${e.message}')),
    );
  } finally {
    if (mounted) setState(() => _busy = false);
  }
}


  @override
  Widget build(BuildContext context) {

    return Scaffold(
  appBar: AppBar(
    title: Text('Deine Tische'),
    centerTitle: true,
    backgroundColor: Colors.transparent,
    elevation: 0,
      actions: [
      IconButton(icon: Icon(Icons.search), onPressed: () {}),
      IconButton(icon: Icon(Icons.filter_2), onPressed: () {}),
    ],
  ),
    body: StreamBuilder<List<TableFr>>(

        stream: _repo.streamAll(),
        builder: (context, snap) {
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final items = snap.data!;
          if (items.isEmpty) {
            return const Center(child: Text('Noch keine Tische, druecke + um einen hinzuzufuegen'));
          }

          return LayoutBuilder(
            builder: (context, constraints) {
              final width = constraints.maxWidth;
              final crossAxisCount = width > 900
                  ? 4
                  : width > 600
                      ? 3
                      : 2;

              return GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  childAspectRatio: 1,
                ),
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  final waiterName = _waiterNameFor(item);
                  final peopleLabel = item.peopleCount == null
                      ? ''
                      : 'Anzahl an Personen: ${item.peopleCount}';

                  return GestureDetector(
                    onTap: () => context.go('/tables/${item.id}/menu'), //TODO CHANGE TO DRINK SELECTION
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: const BorderSide(width: 2),
                      ),
                      child: Stack(
                        children: [

                        //Edit button (top-left)
                          Positioned(
                            top: 6,
                            left: 6,
                            child: IconButton(
                              tooltip: 'Bearbeiten',
                              icon: const Icon(Icons.edit_outlined),
                              onPressed: _busy ? null : () => _edit(item),
                            ),
                          ),

                        // Delete button (top-right)
                          Positioned(
                            top: 6,
                            right: 6,
                            child: IconButton(
                              tooltip: 'Löschen',
                              icon: const Icon(Icons.delete_outline),
                              onPressed: _busy ? null : () => _confirmDelete(context, item),
                              color: Color.from(alpha: 255, red: 255, green: 0, blue: 0),
                            ),
                          ),

                      // Main content
                          Center(
                            child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                item.name,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                waiterName,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                              if (peopleLabel.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(
                                  peopleLabel,
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ],
                            ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );

                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _add,
        icon: const Icon(Icons.add),
        label: const Text('Tisch hinzufuegen'),
      ),
    );
  }
}
