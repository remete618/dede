import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:tmms/core/supabase_client.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:tmms/core/config.dart';
import 'package:tmms/features/items/data/repos/tables_repository.dart';
import 'package:tmms/features/items/data/tablefr.dart';

class PayPage extends StatefulWidget {
  const PayPage({super.key, required this.tableId});
  final int tableId;

  @override
  State<PayPage> createState() => _PayPageState();
}

class _PayPageState extends State<PayPage> {
  final SupabaseClient _db = Supa.client;
  final Map<int, int> _selectedQuantities = {};
  DateTime? _orderTs;
  final _tablesRepo = TablesRepository();
  TableFr? _table;

  @override
  void initState() {
    super.initState();
    _loadLatestOrderTs();
    _loadTable();
  }

  Future<void> _loadTable() async {
    final t = await _tablesRepo.findTableById(widget.tableId);
    if (!mounted) return;
    setState(() {
      _table = t;
    });
  }

  void _setSpecificQty(int id, int qty) {
    setState(() {
      if (qty <= 0) {
        _selectedQuantities.remove(id);
      } else {
        _selectedQuantities[id] = qty;
      }
    });
  }

  Future<void> _loadLatestOrderTs() async {
    final res = await _db
        .from('order_list')
        .select('timestamp')
        .eq('table_idtable', widget.tableId)
        .order('timestamp', ascending: false)
        .limit(1)
        .maybeSingle();

    if (!mounted) return;
    setState(() {
      _orderTs = res == null ? null : DateTime.parse(res['timestamp'] as String);
    });
  }

  Stream<List<Map<String, dynamic>>> _streamPayLines({
    required int tableId,
    required DateTime orderTs,
  }) {
    return _db
        .from('order_lines_view')
        .stream(primaryKey: ['idorder'])
        .map((rows) {
      return rows.where((r) {
        final rTable = (r['table_id'] as num).toInt();
        final rTsStr = r['order_ts'] as String?;
        if (rTsStr == null) return false;

        final rTs = DateTime.parse(rTsStr).toUtc();
        final wanted = orderTs.toUtc();

        return rTable == tableId && rTs == wanted;
      }).toList();
    });
  }

Future<void> _removeSelectedItems(List<Map<String, dynamic>> allRows) async {
    final bool? confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Produkte entfernen?'),
        content: const Text('Möchten Sie die ausgewählten Produkte wirklich vom Tisch löschen?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Abbrechen')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Löschen', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      for (var entry in _selectedQuantities.entries) {
        final id = entry.key;
        final qtyToRemove = entry.value;
        final originalRow = allRows.firstWhere((r) => (r['idorder'] as num).toInt() == id);
        final currentMax = (originalRow['quantity'] as num).toInt();

        if (qtyToRemove >= currentMax) {
          await _db.from('order').delete().eq('idorder', id);
        } else {
          await _db.from('order').update({
            'quantity': currentMax - qtyToRemove,
          }).eq('idorder', id);
        }
      }

      if (!mounted) return;
      setState(() => _selectedQuantities.clear());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Produkte erfolgreich entfernt')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Fehler beim Entfernen: $e'), backgroundColor: Colors.red),
      );
    }
  }

  

  @override
  Widget build(BuildContext context) {
    final ts = _orderTs;


    if (ts == null) {
      return Scaffold(
        backgroundColor: bgClr,
        appBar: AppBar(backgroundColor: bgClr, title: const Text('Bezahlung')),
        body: const Center(child: Text('Noch keine Bestellungen fuer diesen Tisch')),
      );
    }

    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: _streamPayLines(tableId: widget.tableId, orderTs: ts),
      builder: (context, snap) {
        if (snap.hasError) return Scaffold(body: Center(child: Text('Error:\n${snap.error}')));
        if (!snap.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));

        final rows = snap.data!;
        
        final myAppBar = AppBar(
          backgroundColor: bgClr,
          title: Text('Bezahlung – ${_table?.name ?? 'Lädt...'}'),
          actions: [
            if (_selectedQuantities.isNotEmpty)
              IconButton(
                icon: const Icon(Icons.delete_sweep, color: Colors.red),
                onPressed: () => _removeSelectedItems(rows),
                tooltip: 'Ausgewählte entfernen',
              ),
          ],
        );
        
        
        if (rows.isEmpty) return Scaffold(appBar: myAppBar ,body: Center(child: Text('Noch keine Bestellungen')), backgroundColor: bgClr);

        double totalAll = 0;
        double totalSelected = 0;
        for (final r in rows) {
          final id = (r['idorder'] as num).toInt();
          final qty = (r['quantity'] as num).toInt();
          final price = (r['product_price'] as num).toDouble();
          totalAll += qty * price;

          final selectedQty = _selectedQuantities[id] ?? 0;
          totalSelected += selectedQty * price;
        }

        final displayTotal = _selectedQuantities.isEmpty ? totalAll : totalSelected;

        return Scaffold(
          backgroundColor: bgClr,
          appBar: myAppBar,
          body: Column(
            children: [
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: rows.length,
                  separatorBuilder: (_, __) => const Divider(),
                  itemBuilder: (context, i) {
                    final r = rows[i];
                    final id = (r['idorder'] as num).toInt();
                    final name = r['product_name'] as String? ?? '(no name)';
                    final maxQty = (r['quantity'] as num).toInt();
                    final price = (r['product_price'] as num).toDouble();
                    final selectedQty = _selectedQuantities[id] ?? 0;

                    if (maxQty > 1) {
                      return ExpansionTile(
                        leading: Checkbox(
                          value: selectedQty > 0,
                          tristate: selectedQty > 0 && selectedQty < maxQty,
                          onChanged: (_) => _setSpecificQty(id, selectedQty == maxQty ? 0 : maxQty),
                        ),
                        title: Text('$name ($maxQty×)'),
                        subtitle: Text('Ausgewählt: $selectedQty / $maxQty'),
                        trailing: Text('€${(maxQty * price).toStringAsFixed(2)}'),
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                IconButton(
                                  onPressed: () => _setSpecificQty(id, selectedQty - 1),
                                  icon: const Icon(Icons.remove_circle_outline),
                                ),
                                Text('$selectedQty', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                                IconButton(
                                  onPressed: () => _setSpecificQty(id, selectedQty + 1 > maxQty ? maxQty : selectedQty + 1),
                                  icon: const Icon(Icons.add_circle_outline),
                                ),
                              ],
                            ),
                          )
                        ],
                      );
                    }

                    return ListTile(
                      leading: Checkbox(
                        value: selectedQty == 1,
                        onChanged: (_) => _setSpecificQty(id, selectedQty == 1 ? 0 : 1),
                      ),
                      title: Text(name),
                      subtitle: Text('€${price.toStringAsFixed(2)}'),
                      trailing: Text('€${price.toStringAsFixed(2)}'),
                      onTap: () => _setSpecificQty(id, selectedQty == 1 ? 0 : 1),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Text(
                      _selectedQuantities.isEmpty ? 'Gesamtbetrag:' : 'Ausgewählt:',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const Spacer(),
                    Text(
                      '€${displayTotal.toStringAsFixed(2)}',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 80),
            ],
          ),
          floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
          floatingActionButton: SizedBox(
            width: MediaQuery.of(context).size.width * 0.9,
            child: FloatingActionButton.extended(
              onPressed: () => context.go('/tables/${widget.tableId}/menu/pay/checkout', extra: {
                'total': displayTotal,
                'tableId': widget.tableId,
                'selectedQuantities': _selectedQuantities, 
                'allLines': rows, 
              }),
              label: Text(_selectedQuantities.isEmpty ? 'Alles Bezahlen' : 'Ausgewähltes Bezahlen'),
              icon: const Icon(Icons.payment),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
          ),
        );
      },
    );
  }
}