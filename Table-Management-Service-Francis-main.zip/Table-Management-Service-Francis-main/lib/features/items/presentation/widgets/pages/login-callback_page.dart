import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:tmms/core/supabase_client.dart';

class LoginCallbackPage extends StatefulWidget {
  const LoginCallbackPage({super.key});

  @override
  State<LoginCallbackPage> createState() => _LoginCallbackPageState();
}

class _LoginCallbackPageState extends State<LoginCallbackPage> {
  bool _didRun = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _finish());
  }

  Future<void> _finish() async {
    if (_didRun) return;
    _didRun = true;

    final supabase = Supa.client;

    debugPrint('Callback URL: ${Uri.base}');

    try {
      await supabase.auth.getSessionFromUrl(Uri.base);
      //debugPrint('getSessionFromUrl session? ${res.session != null}');
    } catch (e) {
      //debugPrint('getSessionFromUrl error: $e');
    }

    final session = supabase.auth.currentSession;
    //debugPrint('currentSession null? ${session == null}');

    if (!mounted) return;
    context.go(session == null ? '/login' : '/account');
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
