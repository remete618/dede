import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:tmms/core/config.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:tmms/core/supabase_client.dart';

class CheckoutPage extends StatefulWidget {
  final double total;
  final int tableId;
  final Map<int, int> selectedQuantities; 
  final List<Map<String, dynamic>> allLines; 

  const CheckoutPage({
    super.key,
    required this.total,
    required this.tableId,
    required this.selectedQuantities,
    required this.allLines,
  });

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  String _paymentMethod = 'card';
  bool _isLoading = false;
  final SupabaseClient _db = Supa.client;


  //TODO: Implement Saving of Orders in DB instead of deleting
  Future<void> _confirmPayment() async {
    setState(() => _isLoading = true);

    try {
      if (widget.selectedQuantities.isEmpty) {
        for (var row in widget.allLines) {
          final id = (row['idorder'] as num).toInt();
          await _db.from('order').delete().eq('idorder', id);
        }
      } else {
        for (var entry in widget.selectedQuantities.entries) {
          final id = entry.key;
          final qtyToPay = entry.value;

          final originalRow = widget.allLines.firstWhere(
            (r) => (r['idorder'] as num).toInt() == id,
          );
          final currentTotalQty = (originalRow['quantity'] as num).toInt();

          if (qtyToPay >= currentTotalQty) {
            await _db.from('order').delete().eq('idorder', id);
          } else {
            await _db.from('order').update({
              'quantity': currentTotalQty - qtyToPay,
            }).eq('idorder', id);
          }
        }
      }
    if (!mounted) return;
      context.go('/tables');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Fehler bei der Verarbeitung: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgClr,
      appBar: AppBar(
        backgroundColor: bgClr,
        title: const Text('Zahlungsabschluss'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, size: 20),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 40),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Column(
                  children: [
                    Text(
                      'Zu bezahlende Menge',
                      style: TextStyle(
                        color: Colors.grey.shade600,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '€${widget.total.toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                        letterSpacing: -1,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              const Text(
                'Zahlungsmethode',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              _methodTile(
                title: 'Kartenzahlung SumUp (TBD)',
                value: 'card',
                icon: Icons.credit_card_rounded,
              ),
              const SizedBox(height: 12),
              _methodTile(
                title: 'Barzahlung',
                value: 'cash',
                icon: Icons.payments_rounded,
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: _isLoading ? null : _confirmPayment,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(64),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 0,
                ),
                child: _isLoading 
                  ? const CircularProgressIndicator(color: Colors.white) 
                  :Text(
                  'CONFIRM €${widget.total.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _methodTile({
    required String title,
    required String value,
    required IconData icon,
  }) {
    final bool isSelected = _paymentMethod == value;

    return InkWell(
      onTap: () => setState(() => _paymentMethod = value),
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: isSelected ? Colors.black.withOpacity(0.05) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? Colors.black : Colors.transparent,
            width: 2,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.black : Colors.grey,
            ),
            const SizedBox(width: 16),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected ? Colors.black : Colors.black87,
              ),
            ),
            const Spacer(),
            if (isSelected)
              const Icon(Icons.check_circle, color: Colors.black, size: 20),
          ],
        ),
      ),
    );
  }
}