import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:tmms/core/config.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgClr,
      appBar: AppBar(
        backgroundColor: bgClr,
        title: Text('Einstellungen', style: TextStyle(fontWeight: FontWeight.w600, fontSize: abTextSize)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text('Account'),
            subtitle: const Text('Account Einstellungen'),
            onTap: () => context.go('/account'),
          ),
          const Divider(),

          ListTile(
            leading: const Icon(Icons.notifications),
            title: const Text('Benachrichtigungen'),
            subtitle: const Text('Ihre Benachrichtigungen'),
            onTap: () => context.push('/settings/notifications'),
          ),
          const Divider(),

          ListTile(
            leading: const Icon(Icons.palette),
            title: const Text('Aussehen'),
            subtitle: const Text('Theme & display'),
            onTap: () => context.push('/settings/appearance'),
          ),
          const Divider(),

          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Über'),
            subtitle: const Text('Information über uns'),
            onTap: () => context.push('/settings/about'),
          ),
        ],
      ),
    );
  }
}
