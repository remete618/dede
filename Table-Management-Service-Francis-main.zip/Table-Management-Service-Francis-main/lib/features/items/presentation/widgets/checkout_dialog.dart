import 'package:flutter/material.dart';

class CheckoutDialog extends StatelessWidget {
  final double amount;
  final VoidCallback onPayCash;
  final VoidCallback onPayCard;

  const CheckoutDialog({
    super.key,
    required this.amount,
    required this.onPayCash,
    required this.onPayCard,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: const Center(
        child: Text('Zahlung', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Gesamtbetrag: €${amount.toStringAsFixed(2)}',
            style: const TextStyle(
              fontSize: 22,
              color: Colors.green,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          
          SizedBox(
            width: double.infinity,
            height: 56,
            child: FilledButton.icon(
              onPressed: onPayCard,
              icon: const Icon(Icons.credit_card),
              label: const Text('Karte', style: TextStyle(fontSize: 18)),
              style: FilledButton.styleFrom(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),
          const SizedBox(height: 12),
          
          SizedBox(
            width: double.infinity,
            height: 56,
            child: FilledButton.icon(
              onPressed: onPayCash,
              icon: const Icon(Icons.payments),
              label: const Text('Barzahlung', style: TextStyle(fontSize: 18)),
              style: FilledButton.styleFrom(
                backgroundColor: Colors.green,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Abbrechen'),
        ),
      ],
    );
  }
}