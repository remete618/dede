  import 'package:flutter/material.dart';

  class Item {
    final int id;
    final String name;      
    final String? userName;   
    final int peopleCount;

    Item({
      required this.id,
      required this.name,
      this.userName,
      required this.peopleCount,s
    });
  }

  class ItemTile extends StatelessWidget {
  final Item item;
  final VoidCallback onDeletePressed;
  final VoidCallback? onTap;

  const ItemTile({
    super.key,
    required this.item,
    required this.onDeletePressed,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final userLabel =
        item.userName?.isNotEmpty == true ? item.userName! : 'Unassigned';

    return Padding(
      padding: const EdgeInsets.all(8),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Stack(
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(
                  color: Theme.of(context).colorScheme.outlineVariant,
                  width: 2,
                ),
              ),
              child: SizedBox(
                height: 120,
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(item.name,
                          style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Text('-- $userLabel --',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(fontStyle: FontStyle.italic)),
                      const SizedBox(height: 4),
                      Text('People: ${item.peopleCount}',
                          style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 4,
              right: 4,
              child: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: onDeletePressed,
                tooltip: 'Remove table',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

