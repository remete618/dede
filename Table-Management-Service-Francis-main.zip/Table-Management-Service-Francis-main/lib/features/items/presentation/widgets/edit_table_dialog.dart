import 'package:flutter/material.dart';
import '../../data/user.dart';

class EditTableResult {
  final String tableName;
  final int? waiterId;
  final int peopleCount;

  EditTableResult({
    required this.tableName,
    required this.waiterId,
    required this.peopleCount,
  });
}

class EditTableDialog extends StatefulWidget {
  final List<UserModel> users;

  final String initialTableName;
  final int initialPeopleCount;
  final int? initialWaiterId;

  const EditTableDialog({
    super.key,
    required this.users,
    required this.initialTableName,
    required this.initialPeopleCount,
    required this.initialWaiterId,
  });

  static Future<EditTableResult?> prompt({
    required BuildContext context,
    required List<UserModel> users,
    required String initialTableName,
    required int initialPeopleCount,
    required int? initialWaiterId,
  }) {
    return showDialog<EditTableResult>(
      context: context,
      builder: (_) => EditTableDialog(
        users: users,
        initialTableName: initialTableName,
        initialPeopleCount: initialPeopleCount,
        initialWaiterId: initialWaiterId,
      ),
    );
  }

  @override
  State<EditTableDialog> createState() => _EditTableDialogState();
}

class _EditTableDialogState extends State<EditTableDialog> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _peopleCtrl;

  int? _selectedWaiterId;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.initialTableName);
    _peopleCtrl =
        TextEditingController(text: widget.initialPeopleCount.toString());
    _selectedWaiterId = widget.initialWaiterId;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _peopleCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bitte geben sie einen Namen ein')),
      );
      return;
    }

    final people = int.tryParse(_peopleCtrl.text.trim());
    if (people == null || people <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bitte geben sie die Anzahl an Leuten an')),
      );
      return;
    }

    Navigator.pop(
      context,
      EditTableResult(
        tableName: name,
        waiterId: _selectedWaiterId,
        peopleCount: people,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentDropdownValue = _selectedWaiterId ?? -1;

    return AlertDialog(
      title: const Text('Tisch Bearbeiten'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Name',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _peopleCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Anzahl an Gaesten',
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: currentDropdownValue,
              decoration: const InputDecoration(
                labelText: 'Bartender (optional)',
              ),
              items: [
                const DropdownMenuItem<int>(
                  value: -1,
                  child: Text('Offen'),
                ),
                ...widget.users.map(
                  (u) => DropdownMenuItem<int>(
                    value: u.id,
                    child: Text(u.name),
                  ),
                ),
              ],
              onChanged: (value) {
                if (value == null) return;
                setState(() {
                  _selectedWaiterId = (value == -1) ? null : value;
                });
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Abbrechen'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Speichern'),
        ),
      ],
    );
  }
}
