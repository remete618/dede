import 'package:flutter/material.dart';
import '../../data/user.dart';

class AddItemResult {
  final String tableName;
  final int? waiterId;
  final int peopleCount;

  AddItemResult({
    required this.tableName,
    required this.waiterId,
    required this.peopleCount,
  });
}

class AddItemDialog extends StatefulWidget {
  final List<UserModel> users;

  const AddItemDialog({super.key, required this.users});

  static Future<AddItemResult?> prompt(
      BuildContext context, List<UserModel> users) {
    return showDialog<AddItemResult>(
      context: context,
      builder: (_) => AddItemDialog(users: users),
    );
  }

  @override
  State<AddItemDialog> createState() => _AddItemDialogState();
}

class _AddItemDialogState extends State<AddItemDialog> {
  final _nameCtrl = TextEditingController();
  final _peopleCtrl = TextEditingController(text: '2');
  int? _selectedWaiterId; 

  @override
  void dispose() {
    _nameCtrl.dispose();
    _peopleCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a table name')),
      );
      return;
    }

    final people = int.tryParse(_peopleCtrl.text.trim());
    if (people == null || people <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid number of people')),
      );
      return;
    }

    Navigator.pop(
      context,
      AddItemResult(
        tableName: name,
        waiterId: _selectedWaiterId, 
        peopleCount: people,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentDropdownValue = _selectedWaiterId ?? -1;

    return AlertDialog(
      title: const Text('Tisch Hinzufuegen'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Name',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _peopleCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Anzahl an Gaesten',
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: currentDropdownValue,
              decoration: const InputDecoration(
                labelText: 'Bartender (optional)',
              ),
              items: [
                const DropdownMenuItem<int>(
                  value: -1,
                  child: Text('Offen'),
                ),
                ...widget.users.map(
                  (u) => DropdownMenuItem<int>(
                    value: u.id,        
                    child: Text(u.name),
                  ),
                ),
              ],
              onChanged: (value) {
                if (value == null) return;
                setState(() {
                  _selectedWaiterId = (value == -1) ? null : value;
                });
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Abbrechen'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Hinzufuegen'),
        ),
      ],
    );
  }
}
