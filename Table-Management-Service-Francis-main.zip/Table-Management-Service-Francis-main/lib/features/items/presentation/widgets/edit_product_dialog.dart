import 'package:flutter/material.dart';
import 'package:tmms/features/items/data/category.dart';

class EditProductResult {
  final String name;
  final double price;
  final int categoryId;

  EditProductResult({
    required this.name,
    required this.price,
    required this.categoryId,
  });
}

class EditProductDialog extends StatefulWidget {
  const EditProductDialog({
    super.key,
    required this.categories,
    required this.initialName,
    required this.initialPrice,
    required this.initialCategoryId,
  });

  final List<Category> categories;
  final String initialName;
  final double initialPrice;
  final int initialCategoryId;

  static Future<EditProductResult?> prompt({
    required BuildContext context,
    required List<Category> categories,
    required String initialName,
    required double initialPrice,
    required int initialCategoryId,
  }) {
    return showDialog<EditProductResult>(
      context: context,
      builder: (_) => EditProductDialog(
        categories: categories,
        initialName: initialName,
        initialPrice: initialPrice,
        initialCategoryId: initialCategoryId,
      ),
    );
  }

  @override
  State<EditProductDialog> createState() => _EditProductDialogState();
}

class _EditProductDialogState extends State<EditProductDialog> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _priceCtrl;

  int? _selectedCategoryId;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.initialName);
    _priceCtrl = TextEditingController(
      text: widget.initialPrice.toStringAsFixed(2),
    );

    // If the product’s current category no longer exists, fallback to first.
    final exists = widget.categories.any((c) => c.id == widget.initialCategoryId);
    _selectedCategoryId = exists
        ? widget.initialCategoryId
        : (widget.categories.isNotEmpty ? widget.categories.first.id : null);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _priceCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a product name')),
      );
      return;
    }

    final price = double.tryParse(_priceCtrl.text.trim().replaceAll(',', '.'));
    if (price == null || price < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid price')),
      );
      return;
    }

    final catId = _selectedCategoryId;
    if (catId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please choose a category')),
      );
      return;
    }

    Navigator.pop(
      context,
      EditProductResult(
        name: name,
        price: price,
        categoryId: catId,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Produkt bearbeiten'),
      content: SizedBox(
        width: 420,
        child: widget.categories.isEmpty
            ? const Text('No categories found. Add a category first.')
            : Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: _nameCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Name',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _priceCtrl,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Preis',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<int>(
                    value: _selectedCategoryId,
                    decoration: const InputDecoration(
                      labelText: 'Kategorie',
                      border: OutlineInputBorder(),
                    ),
                    items: widget.categories
                        .map((c) => DropdownMenuItem<int>(
                              value: c.id,
                              child: Text(c.name),
                            ))
                        .toList(),
                    onChanged: (v) => setState(() => _selectedCategoryId = v),
                  ),
                ],
              ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Abbrechen'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Speichern'),
        ),
      ],
    );
  }
}
