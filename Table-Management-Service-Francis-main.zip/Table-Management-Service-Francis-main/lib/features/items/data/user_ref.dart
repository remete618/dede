//Tried to list in dropdown per ref but still showing unassigned
//TODO: Fix that stuff
class UserRef {
  final int id;
  final String name;

  UserRef({required this.id, required this.name});

  factory UserRef.fromMap(Map<String, dynamic> m) {
    return UserRef(
      id: (m['id'] as num).toInt(),
      name: (m['name'] as String?) ?? '(no name)',
    );
  }
}
