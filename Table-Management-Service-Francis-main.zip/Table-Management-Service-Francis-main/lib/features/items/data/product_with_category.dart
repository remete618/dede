import 'category.dart';
import 'product.dart';

class ProductWithCategory {
  final Product product;
  final Category category;

  ProductWithCategory({
    required this.product,
    required this.category,
  });
}
