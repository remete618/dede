class UserModel {
  final int id;
  final String name;

  UserModel({
    required this.id,
    required this.name,
  });

  factory UserModel.fromMap(Map<String, dynamic> m) {
    return UserModel(
      id: (m['id'] as num).toInt(),
      name: m['name'] as String,
    );
  }
}
