class TableFr {
  final int id;
  final String name;
  final String? status;
  final int? waiterId;      
  final int? peopleCount;   
  
  TableFr({
    required this.id,
    required this.name,
    this.status,
    this.waiterId,
    this.peopleCount,
  });

  factory TableFr.fromMap(Map<String, dynamic> m) {
    return TableFr(
      id: (m['id'] as num).toInt(),
      name: (m['name'] as String?) ?? '(no name)',
      status: m['status'] as String?,
      waiterId: m['waiter'] == null ? null : (m['waiter'] as num).toInt(),
      peopleCount: m['people_count'] == null
          ? null
          : (m['people_count'] as num).toInt(),
    );
  }

  Map<String, dynamic> toInsert({
    int? waiterIdOverride,
    int? peopleCountOverride,
  }) {
    final data = <String, dynamic>{
      'name': name,
      if (status != null) 'status': status,
    };
    if (waiterIdOverride != null) data['waiter'] = waiterIdOverride;
    if (peopleCountOverride != null) data['people_count'] = peopleCountOverride;
    return data;
  }
}


