import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/supabase_client.dart';
import '../user.dart';

class UsersRepository {
  final SupabaseClient _db = Supa.client;

  Future<List<UserModel>> getAllUsers() async {
    final result =
        await _db.from('user').select('id, name').order('name');


    final list = (result as List)
        .map((row) => UserModel.fromMap(row as Map<String, dynamic>))
        .toList();

    return list;
  }

  Future<UserModel?> getUserById(int id) async {
    final result = await _db
        .from('user')
        .select('id, name')
        .eq('id', id)
        .maybeSingle();

    if (result == null) return null;
    return UserModel.fromMap(result);
  }
}
