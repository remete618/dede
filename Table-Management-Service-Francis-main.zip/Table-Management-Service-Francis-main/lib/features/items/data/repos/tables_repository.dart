import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/supabase_client.dart';
import '../../../../core/config.dart';
import '../tablefr.dart';
import '../user.dart';

class TablesRepository {
  final SupabaseClient _db = Supa.client;

  Stream<List<TableFr>> streamAll() {
    return _db
        .from(itemsTable)
        .stream(primaryKey: ['id'])
        .order('id', ascending: true)
        .map((rows) => rows.map(TableFr.fromMap).toList());
  }

  Future<void> add({
    required String name,
    int? waiterId,
    required int peopleCount,
  }) async {
    final payload = <String, dynamic>{
      'name': name,
      'status': 'open',
      'people_count': peopleCount,
    };
    if (waiterId != null) {
      payload['waiter'] = waiterId;
    }
    await _db.from(itemsTable).insert(payload);
  }
  
  Future<void> delete(int id) async {
    await _db.from(itemsTable).delete().eq('id', id);
  }

  Future<void> update({
  required int id,
  required String name,
  int? waiterId,
  int? peopleCount,
}) async {
  await _db
      .from('table') 
      .update({
        'name': name,
        'people_count': peopleCount,
        'waiter': waiterId,
      })
      .eq('id', id);
}
  

  Future<List<UserModel>> fetchUsers() async {
    final res = await _db
        .from('user')
        .select('id, name')
        .order('name', ascending: true);

    final list = res as List<dynamic>;
    return list.map((row) => UserModel.fromMap(row as Map<String, dynamic>)).toList();
  }

  Future<TableFr?> findTableById(int id) async {
    final res = await _db
        .from(itemsTable)
        .select()
        .eq('id', id)
        .maybeSingle();

    if (res == null) return null;

    return TableFr.fromMap(res as Map<String, dynamic>);
  }

  

}


