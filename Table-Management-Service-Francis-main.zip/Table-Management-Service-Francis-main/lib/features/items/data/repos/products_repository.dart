import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/supabase_client.dart';
import '../../../../core/config.dart';

import '../category.dart';
import '../product.dart';
import '../product_with_category.dart';


class ProductRepository {
  final SupabaseClient _db = Supa.client;

  Stream<List<Product>> streamAll() {
    return _db
        .from('product')
        .stream(primaryKey: ['idproduct'])
        .order('idproduct', ascending: true)
        .map(
          (rows) =>
              rows.map((row) => Product.fromMap(row)).toList(),
        );
  }

  Stream<List<ProductWithCategory>> streamAllWithCategory() {
    return _db
        .from('product')
        .stream(primaryKey: ['idproduct'])
        .order('idproduct')
        .map((rows) {
          return rows.map((row) {
            final product = Product.fromMap(row);
            final category = Category.fromMap(row['category']);
            return ProductWithCategory(
              product: product,
              category: category,
            );
          }).toList();
        });
  }

  Future<void> add({
    required String name,
    required double price,
    required int categoryId,
  }) async {
    await _db.from('product').insert({
      'name': name,
      'price': price,
      'category_idcategory': categoryId,
    });
  }

  Future<void> update({
    required int id,
    String? name,
    double? price,
    int? categoryId,
  }) async {
    final payload = <String, dynamic>{};

    if (name != null) payload['name'] = name;
    if (price != null) payload['price'] = price;
    if (categoryId != null) {
      payload['category_idcategory'] = categoryId;
    }

    await _db
        .from('product')
        .update(payload)
        .eq('idproduct', id);
  }

  Future<void> delete(int id) async {
    await _db.from('product').delete().eq('idproduct', id);
  }



  Future<List<Category>> fetchCategories() async {
    final res = await _db
        .from('category')
        .select('idcategory, name')
        .order('name');

    final list = res as List<dynamic>;
    return list
        .map((row) => Category.fromMap(row))
        .toList();
  }

  //for future me: just for debugging purposses
  Future<int> addReturningId({
  required String name,
  required double price,
  required int categoryId,
}) async {
  final res = await _db
      .from('product')
      .insert({
        'name': name,
        'price': price,
        'category_idcategory': categoryId,
      })
      .select('idproduct')
      .single();

  return res['idproduct'] as int;
}

}
