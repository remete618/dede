import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/supabase_client.dart';

class OrderRepository {
  final SupabaseClient _db = Supa.client;

  /// Get or create active order_list for a table
  Future<DateTime> getOrCreateOrder(int tableId) async {
    final existing = await _db
        .from('order_list')
        .select('timestamp')
        .eq('table_idtable', tableId)
        .order('timestamp', ascending: false)
        .limit(1)
        .maybeSingle();

    if (existing != null) {
      return DateTime.parse(existing['timestamp']);
    }

    final created = await _db
        .from('order_list')
        .insert({'table_idtable': tableId})
        .select('timestamp')
        .single();

    return DateTime.parse(created['timestamp']);
  }

  /// Add or increment product in order
  Future<void> addProduct({
    required int tableId,
    required DateTime orderTimestamp,
    required int productId,
    int quantity = 1,
  }) async {
    final existing = await _db
        .from('order')
        .select('anzahl')
        .eq('product_idproduct', productId)
        .eq('orderlist_timestamp', orderTimestamp.toIso8601String())
        .eq('orderlist_table_idtable', tableId)
        .maybeSingle();

    if (existing == null) {
      await _db.from('order').insert({
        'product_idproduct': productId,
        'anzahl': quantity,
        'orderlist_timestamp': orderTimestamp.toIso8601String(),
        'orderlist_table_idtable': tableId,
      });
    } else {
      await _db.from('order').update({
        'anzahl': (existing['anzahl'] as int) + quantity,
      })
      .eq('product_idproduct', productId)
      .eq('orderlist_timestamp', orderTimestamp.toIso8601String())
      .eq('orderlist_table_idtable', tableId);
    }
  }
}
