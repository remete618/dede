class Product {
  final int id;
  final String? name;
  final double? price;
  final int categoryId;
  final DateTime? createdAt;

  Product({
    required this.id,
    this.name,
    this.price,
    required this.categoryId,
    this.createdAt,
  });

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['idproduct'],
      name: map['name'],
      price: (map['price'] as num?)?.toDouble(),
      categoryId: map['category_idcategory'],
      createdAt: map['created_at'] != null
          ? DateTime.parse(map['created_at'])
          : null,
    );
  }
}
